<?php
class Kontakt_Widget extends WP_Widget
{
	public function __construct()
	{
		$widget_options = array(
			'classname' => 'kontakt',
			'description' => __('Adds a contact form', 'kontakt')
		);
		parent::__construct('kontakt', 'Kontakt', $widget_options);
	}

	public function form($instance)
	{
		$defaults = array(
			'title' => 'Kontakt',
		);
		$instance = wp_parse_args($instance, $defaults);
?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'kontakt') ?> : </label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>">
		</p>

	<?php
	}

	public function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}

	public function widget($args, $instance)
	{
		extract($args);
		echo $before_widget;
		echo $before_title . "Nous Contacter" . $after_title;
	?>
		<form id="formKontakt" method="POST" action="">
			<ul>
				<li>
					<label for="kontakt_name"><?php _e('Your name :', 'kontakt') ?></label>
					<input type="text" id="kontakt_name" name="kontakt_name" value="">
					<div id="errorName" class="errorMessage"></div>
				</li>
				<li>
					<label for="kontakt_firstname"><?php _e('Your firstname :', 'kontakt') ?></label>
					<input type="text" id="kontakt_firstname" name="kontakt_firstname" value="">
					<div id="errorFirstname" class="errorMessage"></div>
				</li>
				<li>
					<label for="kontakt_mail"><?php _e('Your email :', 'kontakt') ?></label>
					<input type="text" id="kontakt_mail" name="kontakt_mail" value="">
					<div id="errorMail" class="errorMessage"></div>
				</li>
				<li>
					<label for="kontakt_tel"><?php _e('Your telephone :', 'kontakt') ?></label>
					<input type="text" id="kontakt_tel" name="kontakt_tel" value="">
					<div id="errorTel" class="errorMessage"></div>
				</li>
				<li class="li2">
					<div class="inputWrap">
						<label for="kontakt_category"><?php _e('Category :', 'kontakt') ?></label>
						<select name="kontakt_category" id="kontakt_category">
							
						</select>
						<div id="errorCategory" class="errorMessage"></div>
					</div>
					<div class="inputWrap">

						<label for="kontakt_subject"><?php _e('Subject of your message :', 'kontakt') ?></label>
						<input type="text" id="kontakt_subject" name="kontakt_subject" value="">
						<div id="errorSubject" class="errorMessage"></div>
					</div>
				</li>
				<li class="li2">
					<label for="kontakt_message"><?php _e('Your message :', 'kontakt') ?></label>
					<textarea name="kontakt_message" id="kontakt_message" cols="30" rows="10"></textarea>
					<div id="errorText" class="errorMessage"></div>
				</li>

				<li>
					<input id="formKontaktSubmit" type="button" value="<?php _e('Submit', 'kontakt') ?>">
				</li>
			</ul>
		</form>
<?php
		echo $after_widget;
	}
}
